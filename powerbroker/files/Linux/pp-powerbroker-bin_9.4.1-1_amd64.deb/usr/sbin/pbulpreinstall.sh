#!/bin/sh
#
# pbcheckinstall - (c) 2013 BeyondTrust Inc
# This script is designed to be run as non-root user
#
# requirement: check for supported OS and patch


addError()
{
    if [ "X$mtool_fmt" = "Xyes" ] ; then
        errorlist=$1
        shift
        while [ $# -gt 0 ]
        do
            errorlist="$errorlist,$1"
            shift
        done
        echo "ErrorStrings" >> $errorFile
        echo "$errorlist" >> $errorFile
        echo "<EOE>" >> $errorFile
    fi
    exit_status_installable=2

}

addWarning()
{
    if [ "X$mtool_fmt" = "Xyes" ] ; then
        warninglist=$1
        shift
        while [ $# -gt 0 ]
        do
            warninglist="$warninglist,$1"
            shift
        done
        echo "WarningStrings" >> $warningFile
        echo "$warninglist" >> $warningFile
        echo "<EOE>" >> $warningFile
    fi
    exit_status_installable=1
}

printMtoolErrors()
{
    if [ "X$mtool_fmt" = "Xyes" ] ; then
        if [ -f $errorFile ];then
            cat $errorFile
        fi
    fi
    /bin/rm -f $errorFile
}

printMtoolWarnings()
{
    if [ "X$mtool_fmt" = "Xyes" ] ; then
        if [ -f $warningFile ];then
            cat $warningFile
        fi
    fi
    /bin/rm -f $warningFile
}

printMtool()
{
    pbtag=$1
    pbvalue=$2
    echo "$pbtag"
    echo "$pbvalue"
    echo "<EOE>"
}

printStdout()
{
    pbtag=$1
    pbvalue=$2
    echo "${pbtag}: ${pbvalue}"

}

printData()
{
    if [ "X$mtool_fmt" = "Xyes" ] ; then
        printMtool "$1" "$2"
    else
        printStdout "$1" "$2"
    fi
}

check_selinux_mode()
{
    selinuxstat="not applicable"
    selinuxtype=
    if [ -f /usr/sbin/semodule ] ; then
        if [ -d /selinux ] ; then
            if [ -f /etc/selinux/config ] ; then
                selinuxmode=`grep '^[ 	]*SELINUX[ 	]*=' /etc/selinux/config 2>/dev/null | sed 's/^.*=[ 	]*//' 2>/dev/null | sed 's/[ 	]*$//' 2>/dev/null`
                selinuxtype=`grep '^[ 	]*SELINUXTYPE[ 	]*=' /etc/selinux/config 2>/dev/null | sed 's/^.*=[ 	]*//' 2>/dev/null | sed 's/[ 	]*$//' 2>/dev/null`
                selinuxstat="$selinuxmode $selinuxtype"
            fi
        fi
    fi
    printData "SELinux" "$selinuxstat"

}

check_local_pbul_ports_blocked()
{
# check to see if ports blocked by firewall; 'iptables'
# aix lsfilt 5.3(L) root
# hpux ipf 11.23 root
# linux iptables root
# osx ipfw root
# solaris ipf 10 root
# 
    : # LBDEL
}

check_port_availability()
{
    netstat -an | grep -v "$2"  2>&1 | grep "$1" >/dev/null 2>&1
    if [ $? -eq 0 ] ; then
        echo "in use"
        addError $3 $2 $1
    else
        grep -v "^[ 	]*$2[ 	]" /etc/services 2>&1 | grep -v '^[ 	]*#'|  grep -w "$1"  >/dev/null 2>&1
        if [ $? -eq 0 ] ; then
            usedby=`grep -v "^[ 	]*$2[ 	]" /etc/services 2>&1 |  grep -w "$1" 2>&1 | awk '{print $1}' | tr '\012' ' '`
            echo "configured for $usedby"
            addError $4 $2 $1 "$usedby"
        else
            echo "available"
        fi
    fi
}


check_local_pbul_ports_avail()
{
    # master on 24345, local on 24346, log on 24347
    # 
    pbul_host_master_port_number=24345
    pbul_host_master_port_avail=""
    pbul_host_local_port_number=24346
    pbul_host_local_port_avail=""
    pbul_host_log_port_number=24347
    pbul_host_log_port_avail=""
    pbul_host_guid_port_number=24348
    pbul_host_guid_port_avail=""
    pbul_host_sguid_port_number=24349
    pbul_host_sguid_port_avail=""
    pbul_host_syncd_port_number=24350
    pbul_host_syncd_port_avail=""

    pbul_host_master_port_avail=`check_port_availability "$pbul_host_master_port_number" "pbmasterd" 1010 1011`
    pbul_host_local_port_avail=`check_port_availability "$pbul_host_local_port_number" "pblocald" 1020 1021`
    pbul_host_log_port_avail=`check_port_availability "$pbul_host_log_port_number" "pblogd" 1030 1031`
    pbul_host_guid_port_avail=`check_port_availability "$pbul_host_guid_port_number" "pbguid" 1040 1041`
    pbul_host_sguid_port_avail=`check_port_availability "$pbul_host_sguid_port_number" "pbsguid" 1050 1051`
    pbul_host_syncd_port_avail=`check_port_availability "$pbul_host_syncd_port_number" "pbsyncd" 1060 1061`

    printData "PowerBroker for Unix & Linux masterd port" "$pbul_host_master_port_number $pbul_host_master_port_avail"
    printData "PowerBroker for Unix & Linux locald port" "$pbul_host_local_port_number $pbul_host_local_port_avail"
    printData "PowerBroker for Unix & Linux logd port" "$pbul_host_log_port_number $pbul_host_log_port_avail"
    printData "PowerBroker for Unix & Linux guid port" "$pbul_host_guid_port_number $pbul_host_guid_port_avail"
    printData "PowerBroker for Unix & Linux sguid port" "$pbul_host_sguid_port_number $pbul_host_sguid_port_avail"
    printData "PowerBroker for Unix & Linux syncd port" "$pbul_host_syncd_port_number $pbul_host_syncd_port_avail"
}

check_superdaemon()
{
    case $my_OS in
        AIX)
            ps $ps_cmd 2>/dev/null | grep "inetd$" >/dev/null 2>&1
            if [ $? -eq 0 ] ; then
                my_sdstat="inetd running"
            else
                my_sdstat="inetd not running"
            fi
            ;;
        HP-UX)
            ps $ps_cmd 2>/dev/null | grep "inetd$" >/dev/null 2>&1
            if [ $? -eq 0 ] ; then
                my_sdstat="inetd running"
            else
                my_sdstat="inetd not running"
            fi
            ;;
        Linux)
            if [ "X`ps -p 1 -o comm=`" = "Xsystemd" ] ; then
                my_sdstat="systemd running"
            else
            ps $ps_cmd 2>/dev/null | grep "xinetd$" >/dev/null 2>&1
            if [ $? -eq 0 ] ; then
                my_sdstat="xinetd running"
            else
                ps $ps_cmd 2>/dev/null | grep "inetd$" >/dev/null 2>&1
                if [ $? -eq 0 ] ; then
                    my_sdstat="inetd running"
                else
                    my_sdstat="xinetd not running"
                    fi
                fi
            fi
            ;;
        "Mac OS X")
            launchctl list >/dev/null 2>&1
            if [ $? -eq 0 ] ; then
                my_sdstat="launchd running"
            else
                my_sdstat="launchd not running"
            fi
            ;;
        Solaris|"Solaris Express")
            case $my_OSNum in
                8|9)
                    ps $ps_cmd 2>/dev/null | grep "inetd$" >/dev/null 2>&1
                    if [ $? -eq 0 ] ; then
                        my_sdstat="inetd running"
                    else
                        my_sdstat="inetd not running"
                    fi
                    ;;
                *) #1011
                    svccfg list >/dev/null 2>&1
                    if [ $? -eq 0 ] ; then
                        my_sdstat="SMF running"
                    else
                        my_sdstat="SMF not running"
                    fi
                    ;;
            esac
            ;;
    esac

    printData "Super daemon status" "$my_sdstat"
    if echo "$my_sdstat" | grep "not running" >/dev/null 2>&1 ; then
        service=`echo "$my_sdstat" | awk '{print $1}'`
        addError 2030 $service
    fi
}

get_domainname()
{
    my_domainname=`domainname` >/dev/null 2>&1
    if [ "X$my_domainname" = "X" ] ; then
        my_domainname="unknown"
        addWarning 1080
    else
        echo "$my_domainname" | grep "localdomain" >/dev/null 2>&1
        if [ $? -eq 0 ] ; then
            my_domainname="Invalid domainname: '$my_domainname'"
            addWarning 1090 $my_domainname
        fi
    fi
    printData "Domainname" "$my_domainname"

}

get_defgateway()
{
    case $my_OS in
        AIX)
            my_defgateway=`netstat -r 2>/dev/null | grep 'default' | grep 'UG' | $awk '{ print $2 }' 2>/dev/null | sort -u 2>/dev/null`
            ;;
        HP-UX)
            my_defgateway=`netstat -r 2>/dev/null | grep 'default' | grep 'UG' | $awk '{ print $2 }' 2>/dev/null | sort -u 2>/dev/null`
            ;;
        Linux)
            my_defgateway=`route -n 2>/dev/null | grep '^0.0.0.0' |  grep 'UG[ /t]' | $awk '{ print $2 }' 2>/dev/null | sort -u 2>/dev/null`
            # 'route -n' ~ 'netstat -r'
            ;;
        "Mac OS X")
            my_defgateway=`netstat -r 2>/dev/null |  grep 'default' | grep 'UG' | $awk '{ print $2 }' 2>/dev/null | sort -u 2>/dev/null`
            ;;
        Solaris|"Solaris Express")
            my_defgateway=`netstat -r 2>/dev/null |  grep 'default' | grep 'UG' | $awk '{ print $2 }' 2>/dev/null | sort -u 2>/dev/null`
            ;;
    esac
    if [ "X$my_defgateway" = "X" ] ; then 
        my_defgateway="undetermined" 
        addWarning 1020 
    fi

    printData "Default gateway" "$my_defgateway"
}

check_NICs()
{
    case $my_OS in
        AIX)
             my_nics=`netstat -i  2>/dev/null | sed 's/^[ 	].*//' 2>/dev/null | $awk '$1 == "Name" { next } $1=="" { next } $1 ~ "lo" { next } $1 ~ "IPv" { next } { print $1 }' 2>/dev/null | sort -u 2>/dev/null`
            list_ipaddresses=""
            list_nics=""
            for my_nic in $my_nics ; do
                my_ipaddress=`ifconfig $my_nic 2>/dev/null | $awk '$1 == "inet" { print $2 }' 2>/dev/null | sed 's&/.*&&' 2>/dev/null`
                for each_ipaddress in $my_ipaddress ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress"
                    list_nics="$list_nics $my_nic"
                done
                my_ipaddress6=`ifconfig $my_nic 2>/dev/null | $awk '$1 == "inet6" { print $2 }'  2>/dev/null | sed 's&/.*&&' 2>/dev/null`
                for each_ipaddress6 in $my_ipaddress6 ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress6"
                    list_nics="$list_nics $my_nic"
                done
            done
            ;;
        HP-UX)
             my_nics=`netstat -i 2>/dev/null | sed 's/^[ 	].*//' 2>/dev/null | $awk '$1 == "Name" { next } $1=="" { next } $1 ~ "lo" { next } $1 ~ "IPv" { next } { print $1 }' 2>/dev/null | sort -u 2>/dev/null`
            list_ipaddresses=""
            list_nics=""
            for my_nic in $my_nics ; do
                my_ipaddress=`ifconfig $my_nic 2>/dev/null | $awk '$1 == "inet" { print $2 }' 2>/dev/null `
                for each_ipaddress in $my_ipaddress ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress"
                    list_nics="$list_nics $my_nic"
                done
                my_ipaddress6=`ifconfig $my_nic 2>/dev/null | $awk '$1 == "inet6" { print $2 }' 2>/dev/null`
                for each_ipaddress6 in $my_ipaddress6 ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress6"
                    list_nics="$list_nics $my_nic"
                done
            done
            ;;
        Linux)
             my_nics=`netstat -i 2>/dev/null 2>/dev/null | sed 's/^[ 	].*//' 2>/dev/null | $awk '$1 == "Kernel" { next } $1 == "Iface" { next } $1=="" { next } $1 ~ "lo" { next } $1 ~ "IPv" { next } { print $1 }' 2>/dev/null | sort -u 2>/dev/null`
            list_ipaddresses=""
            list_nics=""
            for my_nic in $my_nics ; do
                my_ipaddress=`ip -o -4 addr show dev $my_nic 2>/dev/null | $awk '{ print $4 }' 2>/dev/null | sed 's&/.*&&' 2>/dev/null`
                for each_ipaddress in $my_ipaddress ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress"
                    list_nics="$list_nics $my_nic"
                done
                my_ipaddress6=`ip -o -6 addr show dev $my_nic 2>/dev/null | $awk '{ print $4 }' 2>/dev/null | sed 's&/.*&&' 2>/dev/null`
                for each_ipaddress6 in $my_ipaddress6 ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress6"
                    list_nics="$list_nics $my_nic"
                done
            done

            ;;
        "Mac OS X")
             my_nics=`netstat -i 2>/dev/null | sed 's/^[ 	].*//' 2>/dev/null | $awk '$1 == "Name" { next } $1=="" { next } $1 ~ "lo" { next } $1 ~ ".*[\*]" { next } $1 ~ "IPv" { next } { print $1 }' 2>/dev/null | sort -u 2>/dev/null`
            list_ipaddresses=""
            list_nics=""
            for my_nic in $my_nics ; do
                my_ipaddress=`ifconfig $my_nic 2>/dev/null | $awk '$1 == "inet" { print $2 }' 2>/dev/null`
                for each_ipaddress in $my_ipaddress ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress"
                    list_nics="$list_nics $my_nic"
                done
                my_ipaddress6=`ifconfig $my_nic 2>/dev/null | $awk '$1 == "inet6" { print $2 }' 2>/dev/null`
                for each_ipaddress6 in $my_ipaddress6 ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress6"
                    list_nics="$list_nics $my_nic"
                done
            done
            ;;
        Solaris|"Solaris Express")
            my_nics=`netstat -i 2>/dev/null | sed 's/^[ 	].*//' 2>/dev/null | $awk '$1 == "Name" { next } $1=="" { next } $1 ~ "lo" { next } $1 ~ "IPv" { next } { print $1 }' 2>/dev/null | sort -u 2>/dev/null`
            list_ipaddresses=""
            list_nics=""
            for my_nic in $my_nics ; do
                my_ipaddress=`ifconfig $my_nic  2>/dev/null | $awk '$1 == "inet" { print $2 }' 2>/dev/null`
                for each_ipaddress in $my_ipaddress ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress"
                    list_nics="$list_nics $my_nic"
                done
                my_ipaddress6=`ifconfig $my_nic 2>/dev/null | $awk '$1 == "inet6" { print $2 }' 2>/dev/null`
                for each_ipaddress6 in $my_ipaddress6 ; do
                    list_ipaddresses="$list_ipaddresses $each_ipaddress6"
                    list_nics="$list_nics $my_nic"
                done
            done
            ;;
    esac

        set $list_ipaddresses
        for each_nic in $list_nics ; do
            each_ipaddress=$1
            shift
            printData "NIC" "$each_nic $each_ipaddress"
        done

    NIC_Failures=""
    if [ ! -z "$hostfileip" -a ! -z "$list_ipaddresses" ]; then
        for singleipaddress in $hostfileip ; do
            if echo "$list_ipaddresses" | grep "$singleipaddress" >/dev/null 2>/dev/null ; then
                : 
            else
                printData "NIC" "hostfileip $singleipaddress is not in $list_ipaddresses"
                if [ "$singleipaddress" != "127.0.0.1" -a "$singleipaddress" != "::1" ];then
                    NIC_Failures="yes"
                    addError 3000 $singleipaddress "$list_ipaddresses"
                else
                    addWarning 1000 $singleipaddress "$list_ipaddresses"
                fi
            fi 
        done
    fi
}

validate_nameresol()
{
    # arg1 = nodename
    arg_hostname="$1"
    nameresol_check="passed"
    case $my_OS in
        AIX)
            #my_dnsip=`$host $arg_hostname | sed 's/^.*is //'` # poss mult
            my_dnsip=`$host $arg_hostname 2>/dev/null | sed 's/^.*[ e][is][ss] //' | sed 's/[ ,].*$//' 2>/dev/null` # poss 'Alias'
            if [ $? -ne 0 ] ; then
                nameresol_check="DNS lookup failed"
                addError 3010 $arg_hostname
            else
                ctr1=0
                for item in $my_dnsip ; do
                    if [ $ctr1 -eq 0 ] ; then
	                $host $item >/dev/null 2>&1
	                if [ $? -ne 0 ] ; then
	                    nameresol_check="reverse DNS lookup failed for: $item"
                            addError 3020 $arg_hostname $item
	                fi
                    fi
                done
            fi
            ;;
        "Mac OS X")
            my_dnsip=`host $arg_hostname 2>/dev/null | sed 's/^.*address //' 2>/dev/null`
            if [ $? -ne 0 ] ; then
                nameresol_check="DNS lookup failed"
                addError 3010 $arg_hostname
            else
                ctr1=0
                for item in $my_dnsip ; do
                    if [ $ctr1 -eq 0 ] ; then
	                host $item >/dev/null 2>&1
	                if [ $? -ne 0 ] ; then
	                    nameresol_check="reverse DNS lookup failed for: $item"
                            addError 3020 $arg_hostname $item
                            ctr1=1
	                fi
                    fi
                done
            fi
            ;;
        Linux)
            my_dnsip=`host $arg_hostname 2>/dev/null | sed 's/^.*address //' 2>/dev/null`
            result1=$?
            echo $my_dnsip | grep "not found" >/dev/null 2>&1
            result2=$?
            if [ $result1 -ne 0 -o $result2 -eq 0 ] ; then
                nameresol_check="DNS lookup failed"
                addError 3010 $arg_hostname
            else
                ctr1=0
                for item in $my_dnsip ; do
                    if [ $ctr1 -eq 0 ] ; then
	                my_dnsname=`host  $item 2>/dev/null`
	                result3=$?
	                echo $my_dnsname | grep "not found" >/dev/null 2>&1
	                result4=$?
	                if [ $result3 -ne 0 -o $result4 -eq 0 ] ; then
	                    nameresol_check="reverse DNS lookup failed for: $item"
                            addError 3020 $arg_hostname $item
                            ctr1=1
                        fi
                    fi
                done
            fi
            ;;
        HP-UX)
            case $my_OSNum in
                00|11)
                    awkprog=" BEGIN { namefound=0 } { if ( \$1 == \"Name:\" ) { namefound=1 } if ( \$1 == \"Address:\" && namefound == 1 ) { print \$2 } } "
                    my_dnsip=`nslookup $arg_hostname 2>&1 | $awk "$awkprog" 2>/dev/null`
                    if [ "X$my_dnsip" = "X" ] ; then
	                nameresol_check="DNS lookup failed"
                        addError 3010 $arg_hostname
	            else
	                ctr1=0
	                for item in $my_dnsip ; do
                            if [ $ctr1 -eq 0 ] ; then
                                my_dnsname=`nslookup $item 2>&1 | $awk "$awkprog" 2>/dev/null`
                                if [ "X$my_dnsname" = "X" ] ; then
		                    nameresol_check="reverse DNS lookup failed for: $item"
                                    addError 3020 $arg_hostname $item
	                            ctr1=1
                                fi
                            fi
	                done
	            fi
                    ;;
                *) #233141
                    my_dnsip=`host $arg_hostname 2>/dev/null | sed 's/^.*address //' 2>/dev/null`
                    result1=$?
                    echo $my_dnsip | grep "not found" >/dev/null 2>&1
                    result2=$?
                    if [ $result1 -ne 0 -o $result2 -eq 0 ] ; then
                        nameresol_check="DNS lookup failed"
                        addError 3010 $arg_hostname
                    else
                        ctr1=0
                        for item in $my_dnsip ; do
                            if [ $ctr1 -eq 0 ] ; then
                                my_dnsname=`host $item`
                                result3=$?
                                echo $my_dnsname | grep "not found" >/dev/null 2>&1
                                result4=$?
                                if [ $result3 -ne 0 -o $result4 -eq 0 ] ; then
                                    nameresol_check="reverse DNS lookup failed for: $item"
                                    addError 3020 $arg_hostname $item
                                    ctr1=1
                                fi
                            fi
                        done
                    fi
                    ;;

            esac
            ;;
        Solaris|"Solaris Express")
            case $my_OSNum in
                8|9)
                    awkprog=" BEGIN { namefound=0 } { if ( \$1 == \"Name:\" ) { namefound=1 } if ( \$1 == \"Address:\" && namefound == 1 ) { print \$2 } } "
                    my_dnsip=`nslookup $arg_hostname 2>&1 | $awk "$awkprog" 2>/dev/null`
                    if [ "X$my_dnsip" = "X" ] ; then
	                nameresol_check="DNS lookup failed"
                        addError 3010 $arg_hostname
	            else
	                ctr1=0
	                for item in $my_dnsip ; do
                            if [ $ctr1 -eq 0 ] ; then
                                my_dnsname=`nslookup $item 2>&1 | $awk "$awkprog" 2>/dev/null`
                                if [ "X$my_dnsname" = "X" ] ; then
		                    nameresol_check="reverse DNS lookup failed for: $item"
                                    addError 3020 $arg_hostname $item
	                            ctr1=1
                                fi
                            fi
	                done
	            fi
                    ;;
                *) #1011
	            my_dnsip=`host $arg_hostname 2>/dev/null | sed 's/^.*address //' 2>/dev/null`
	            if [ $? -ne 0 ] ; then
	                nameresol_check="DNS lookup failed"
                        addError 3010 $arg_hostname
	            else
	                ctr1=0
	                for item in $my_dnsip ; do
	                    if [ $ctr1 -eq 0 ] ; then
		                host $item >/dev/null 2>&1
		                if [ $? -ne 0 ] ; then
		                    nameresol_check="reverse DNS lookup failed for: $item"
                                    addError 3020 $arg_hostname $item
	                            ctr1=1
		                fi
	                    fi
	                done
	            fi
                    ;;
            esac
            ;;
    esac
    nameresol_resultlist="$nameresol_resultlist|$nameresol_check"
    nameresol_hostlist="$nameresol_hostlist|$arg_hostname"
    dnsiplist="$my_dnsip" # because we're going to use elsewhere... but only for the first one (current host).

    if [ "X$nameresol_check" != "Xpassed" ]; then
        name_resolution_errors=1
    fi


}

print_validate_nameresol()
{
        sav_IFS="$IFS"
        IFS="|"
        mastervalue=""
        set $nameresol_hostlist
        for nameresol_result in $nameresol_resultlist ; do
            nameresol_host=$1
            shift
            if [ "X$nameresol_host" != "X" ] ; then # nameresol_host="|host|master1|master2"
                printData "Name resolution" "${mastervalue}${nameresol_host} $nameresol_result"
                mastervalue="master "
            fi
        done
        IFS="$sav_IFS"
}

validate_resolv()
{
    resolv_check="passed"
    case $my_OS in
        "Mac OS X")
            resolvFile="/Library/Preferences/SystemConfiguration/preferences.plist"
            if [ ! -f "/Library/Preferences/SystemConfiguration/preferences.plist" ] ; then
                resolv_check="/Library/Preferences/SystemConfiguration/preferences.plist not found"
                addWarning 1040
            else
                resolv_check2=""
                resolvperms=`ls -l /Library/Preferences/SystemConfiguration/preferences.plist 2>/dev/null | $awk '{print $1 }' 2>/dev/null | sed 's/-rw-r--r--//' 2>/dev/null`
                if [ "X$resolvperms" != "X" ] ; then
                    resolv_check2="file permissions incorrect ; "
                    addWarning 1050 $resolvFile
                fi
                nameservers=`cat /Library/Preferences/SystemConfiguration/preferences.plist 2>/dev/null | $awk 'BEGIN { flag1=0 } $1 ~ "ServerAddresses" { flag1=1 } $1 ~ "string" && flag1 == 1 { print $1 ; exit }' 2>/dev/null | sed 's/^<string>//' 2>/dev/null | sed 's/<\/string>//' 2>/dev/null`
                if [ "X$nameservers" = "X" ] ; then
                    resolv_check2="${resolv_check2}'nameserver' not defined ; "
                    addWarning 1060
                fi
                domains=`cat /Library/Preferences/SystemConfiguration/preferences.plist  2>/dev/null | $awk 'BEGIN { flag1=0 } $1 ~ "SearchDomains" { flag1=1 } $1 ~ "string" && flag1 == 1 { print $1 ; exit }' 2>/dev/null | sed 's/^<string>//' 2>/dev/null | sed 's/<\/string>//' 2>/dev/null`
                if [ "X$domains" = "X" ] ; then
                    resolv_check2="${resolv_check2}'domain' not defined"
                    addWarning 1070
                fi
                if [ "X$resolv_check2" != "X" ] ; then
                    resolv_check="$resolv_check2 /Library/Preferences/SystemConfiguration/preferences.plist"
                fi
            fi
            ;;
        *)
            resolvFile="/etc/resolv.conf"
            if [ ! -f "/etc/resolv.conf" ] ; then
                resolv_check="/etc/resolv.conf not found"
                addWarning 1030
            else
                resolv_check2=""
                resolvperms=`ls -l /etc/resolv.conf 2>/dev/null | $awk '{print $1 }' 2>/dev/null | sed 's/.rw.r..r..\.*//' 2>/dev/null`
                if [ "X$resolvperms" != "X" ] ; then
                    resolv_check2="file permissions incorrect ; "
                    addWarning 1050 $resolvFile
                fi
                nameservers=`cat /etc/resolv.conf 2>/dev/null | grep -v "^#" 2>/dev/null | grep "nameserver" 2>/dev/null | $awk '{ print $2 ; exit }' 2>/dev/null`
                if [ "X$nameservers" = "X" ] ; then
                    resolv_check2="${resolv_check2}'nameserver' not defined ; "
                    addWarning 1060
                fi
                domains=`cat /etc/resolv.conf 2>/dev/null | grep -v "^#" 2>/dev/null | grep "domain" 2>/dev/null | $awk '{ print $2 }' 2>/dev/null`
                searches=`cat /etc/resolv.conf  2>/dev/null | grep -v "^#" 2>/dev/null | grep "search" 2>/dev/null | $awk '{ print $2 }' 2>/dev/null `
                if [ "X$domains" = "X" -a "X$searches" = "X" ] ; then
                    resolv_check2="${resolv_check2}'domain' or 'search' not defined"
                    addWarning 1070
                fi
                if [ "X$resolv_check2" != "X" ] ; then
                    resolv_check="$resolv_check2"
                fi
            fi
            ;;
    esac

    printData "DNS resolv.conf" "$resolv_check"

}

gethostfileip()
{
    #hostfileip=`grep "[ \t]$my_hostname[. \t]" /etc/hosts | grep -v "^#" | awk '{ print $1 }'`
    hostfileip=`grep "[ 	]$my_hostname[. 	]" /etc/hosts 2>/dev/null | grep -v "^#" 2>/dev/null | awk '{ print $1 }' 2>/dev/null | head -1 2>/dev/null`
    if [ -z "$hostfileip" ]; then
        hostfileip=`grep "[ 	]$my_hostname$" /etc/hosts 2>/dev/null | grep -v "^#" 2>/dev/null | awk '{ print $1 }' 2>/dev/null | head -1 2>/dev/null`
    fi
}

validate_etchosts()
{
    etchosts_check="passed"
    if [ -f "/etc/hosts" ];then
        etchostsperms=`ls -l /etc/hosts 2>/dev/null | $awk '{print $1 }' 2>/dev/null | sed 's/.r..r..r..\.*//' 2>/dev/null`
        if [ "X$etchostsperms" != "X" ] ; then
            etchosts_check="permissions incorrect"
        fi
    else
        etchosts_check="missing"
    fi
    printData "Hosts file" "$etchosts_check"
}

validate_nsswitch()
{
    nsswitch_name="Name Services"
    nsswitch_check="passed"
    if [ -f "/etc/hosts" -a "$my_hostname" != "unknown" ] ; then
        gethostfileip
    fi
    case $my_OS in
        AIX)
            if [ ! -f "/etc/netsvc.conf" ] ; then
                nsswitch_check2="/etc/netsvc.conf not found"
                addWarning 1100 "/etc/netsvc.conf"
            else
                nsswitch_check2=""
                nssperms=`ls -l /etc/netsvc.conf 2>/dev/null | $awk '{print $1 }' 2>/dev/null | sed 's/-..-..-.--//' 2>/dev/null`
                if [ "X$nssperms" != "X" ] ; then
                    nsswitch_check2="file permissions incorrect ; "
                    addWarning 1110 "/etc/netsvc.conf"
                fi
                my_nsshost=`cat /etc/netsvc.conf 2>/dev/null | grep -v "^#" 2>/dev/null | grep "^hosts = " 2>/dev/null | sed 's/,/ /g' 2>/dev/null`
                if [ "X$my_nsshost" = "X" ] ; then
                    nsswitch_check2="${nsswitch_check2}'hosts =' not defined ;"
                    addWarning 1120 
                else
                        if [ ! -z "$hostfileip" ]; then
                            for singleipaddress in $hostfileip ; do
                                echo "$dnsiplist" | grep "$singleipaddress" >/dev/null 2>&1
                                if [ $? -ne 0 ] ; then
                                    nsswitch_check2="${nsswitch_check2}/etc/hosts $my_hostname ip address $singleipaddress does not agree with resolver ip address $dnsiplist"
                                    addWarning 1140 "$my_hostname" "$singleipaddress" "$dnsiplist"
                                fi
                            done
                        fi
                fi
            fi
            ;;
        HP-UX|Linux|Solaris|"Solaris Express")
            if [ ! -f "/etc/nsswitch.conf" ] ; then
                nsswitch_check2="/etc/nsswitch.conf not found"
                addWarning 1100 "/etc/netsvc.conf"
            else
                nsswitch_check2=""
                nssperms=`ls -l /etc/nsswitch.conf 2>/dev/null | $awk '{print $1 }' 2>/dev/null | sed 's/-..-.--.--\.*//' 2>/dev/null`
                if [ "X$nssperms" != "X" ] ; then
                    nsswitch_check2="file permissions incorrect ; "
                    addWarning 1110 "/etc/nsswitch.conf"
                fi
                my_nsshost=`cat /etc/nsswitch.conf 2>/dev/null | grep -v "^#" 2>/dev/null | grep "^hosts:" 2>/dev/null`
                if [ "X$my_nsshost" = "X" ] ; then
                    nsswitch_check2="${nsswitch_check2}'hosts:' not defined ;"
                    addWarning 1120 
                else
                        if [ ! -z "$hostfileip" ]; then
                            for singleipaddress in $hostfileip ; do
                                echo "$dnsiplist" | grep "$singleipaddress" >/dev/null 2>&1
                                if [ $? -ne 0 ] ; then
                                    nsswitch_check2="${nsswitch_check2}/etc/hosts $my_hostname ip address $singleipaddress does not agree with resolver ip address $dnsiplist"
                                    addWarning 1140 "$my_hostname" "$singleipaddress" "$dnsiplist"
                                fi
                            done
                        fi
                fi
            fi
            ;;
        "Mac OS X")
            nsswitch_check="not applicable"
            ;;
    esac

    if [ -z "$hostfileip" ];then
        echo "$my_nsshost" | grep dns >/dev/null 2>/dev/null
        if [ $? -ne 0 ];then
            addWarning 1150 $my_hostname
            if [ -z "$nsswitch_check2" ];then
                nsswitch_check2="/etc/hosts does not contain I.P. address for $my_hostname and DNS may not be not in use."
            else
                nsswitch_check2="$nsswitch_check2 /etc/hosts does not contain I.P. address for $my_hostname and DNS may not be not in use."
            fi
        fi
    fi

    if [ "X$nsswitch_check2" != "X" ] ; then
        nsswitch_check="$nsswitch_check2"
    fi

    printData "$nsswitch_name" "$nsswitch_check"
}

get_hostname()
{
    my_hostname=`hostname` >/dev/null 2>&1
    if [ "X$my_hostname" = "X" ] ; then
        my_hostname="unknown"
        hostname_error=1
        addError 2010
    else
        echo "$my_hostname" | grep "localhost" >/dev/null 2>&1
        if [ $? -eq 0 ] ; then
            addError 2020 $my_hostname
            my_hostname="Invalid hostname: '$my_hostname'"
            hostname_error=1
        fi
    fi

    printData "Hostname" "$my_hostname"
}

set_variables()
{
    nameresol_resultlist=""
    nameresol_hostlist=""

}

check_console_time()
{
    max_offset=60 # seconds
    my_longtime_UTC=`date -u '+%Y%m%d%H%M%S'`
    time_offset=`expr $console_time - $my_longtime_UTC 2>/dev/null`
    if [ $time_offset -gt $max_offset -o $time_offset -lt -$max_offset ] ; then
        my_offset="offset over $max_offset seconds"
        addWarning 1010 "$time_offset" "$max_offset"
    else
        my_offset="offset within $max_offset seconds"
    fi

}

get_masters()
{
    if [ "X$my_masternames" = "X" ] ; then
        if [ -f "/etc/${prefix}pb.settings${suffix}" ] ; then
            my_masternames=`grep "^submitmasters" "/etc/${prefix}pb.settings${suffix}"`
            if [ "X$my_masternames" != "X" ] ; then
                my_masternames=`echo "$my_masternames" | sed 's/^submitmasters *//' 2>/dev/null`
            fi
        fi
    fi

}

set_OSVars()
{
    awk=awk
    case $my_OS in
        AIX)
            if [ "$my_OSVer" = "5.1" ] ; then
                host="host"
            else
                host="host -n"
            fi
            ps_cmd='-e'
            PATH=$PATH:/usr/sbin:/etc # ifconfig
            ;;
        HP-UX)
            ps_cmd='-e'
            PATH=$PATH:/usr/sbin # ifconfig
            ;;
        Solaris|"Solaris Express")
            awk=/usr/xpg4/bin/awk
            if [ ! -f "$awk" ] ; then
                echo "${i_am}: required utility '$awk' not found"
                addError 1090
                exit 1
            fi
            ps_cmd='-e'
            PATH=$PATH:/usr/sbin # nslookup ifconfig host svccfg
            ;;
        "Mac OS X")
            ps_cmd="ax"
            PATH=$PATH:/sbin:/usr/sbin # ifconfig netstat
            ;;
        Linux)
            ps_cmd="-e"
            PATH=$PATH:/sbin # ip route
            ;;
    esac

}

set_OSVer()
{
    case $my_OS in
        AIX)
            my_OSVer="${my_OSVer2}.${my_OSVer}"
            #my_OSPat=`/usr/bin/oslevel -s`
            ;;
        HP-UX)
            my_OSVer=`echo $my_OSVer | sed 's/^[A-Z]\.//' 2>/dev/null`
            my_OSNum=`echo $my_OSVer | cut -d'.' -f2 2>/dev/null` #0011233141
            ;;
        SunOS)
            # my_OSVer OK
            if [ "X$my_OSVer2" = "Xsnv_151a" ] ; then
                my_OS="Solaris Express"
            else
                my_OS="Solaris"
            fi
            my_OSNum=`echo $my_OSVer | cut -d'.' -f2 2>/dev/null` #91011
            #my_OSPat=`$SED </etc/release -n -e 's/^[^_]*_\([^_]\{1,\}[0-9]\{1,\}\).*$/\1/p'`
            #showrev -p
            ;;
        Darwin)
            my_OS="Mac OS X"
            my_OSVer=`sw_vers -productVersion`
            ;;
        Linux)
            # VMware ESX 4.0 (Kandinsky)
            # VMware ESX Server 3
            if [ -f "/etc/vmware-release" ] ; then my_OSVer=`cat /etc/vmware-release` ; fi
            # Red Hat Enterprise Linux ES release 4 (Nahant Update 6)
            # Red Hat Enterprise Linux Server release 6.1 (Santiago)
            # also covers CentOS, Fedora, OEL
            if [ -f "/etc/redhat-release" -a ! -f "/etc/vmware-release" ] ; then my_OSVer=`cat /etc/redhat-release` ; fi
            # SUSE Linux Enterprise Server 11 (x86_64)
            # VERSION = 11
            # PATCHLEVEL = 0
            # openSUSE 11.2 (x86_64)
            if [ -f "/etc/SuSE-release" ] ; then my_OSVer=`cat /etc/SuSE-release | grep "SUSE"` ; fi
            # 5.0.6 # Debian
            if [ -f "/etc/debian_version" -a ! -f "/etc/lsb-release" ] ; then
                my_OSVer=`cat /etc/debian_version`
                my_OSVer="Debian $my_OSVer"
            fi
            # Ubuntu 10.04.4 LTS
            if [ -f "/etc/lsb-release" -a -f "/etc/issue.net" -a ! -f "/etc/redhat-release" -a ! -f "/etc/SuSE-release" ]; then my_OSVer=`cat /etc/issue.net` ; fi
            ;;
        *)
            ;; # leave as is
    esac

    if [ "X$my_OS" = "X" ] ; then
        my_OS="unknown"
        my_OSVer="unknown"
    fi
    printData "OS" "$my_OS"
    printData "OS Version" "$my_OSVer"
}

PB_Installplatform_hp11Arch()
{
	getconf KERNEL_BITS >/dev/null 2>&1
	if [ $? -eq 0 ] ; then
	    KERNEL_BITS=`getconf KERNEL_BITS`
	else
	    KERNEL_BITS=0
	fi
	case X${KERNEL_BITS} in
	   X64)
#no more hpuxC. hpuxB works on both
#		arch=hppa_hpuxC
#		arch=hppa_hpuxB
# 11.23 and above can use B or D
		osrlsfld3=`uname -r 2>/dev/null | cut -d'.' -f3 2>/dev/null`
		if [ $osrlsfld3 -ge 23 ] ; then
		    oldarch=hppa_hpuxD; arch=hpux.hppa64
		else
		    arch=unsupported #unsupported arch=hppa_hpuxB
		fi
		;;
	   X32)
		arch=unsupported #unsupported arch=hppa_hpuxB
		;;
	   X*)
		#PB_Installplatform_multipleArch hppa_hpuxB hppa_hpuxC hppa_hpuxD
		oldarch=hppa_hpuxD; arch=hpux.hppa64
		;;
	esac

}

PB_Installplatform_ia64hpuxArch() {
	oldarch=ia64_hpuxA; arch=hpux.ia64
}

PB_Installplatform_sol11Arch()
{
    myunamev=`uname -v` >/dev/null 2>&1
    case $myunamev in
        snv_*) # Express
            case $choice in
                sun4*:*:*:*)    oldarch=sparc_solarisC; arch=solaris9-10.sparc ;;
                i86pc:*:*:*)    oldarch=x86_solarisB; arch=solaris9-10.x86 ;;
            esac
            ;;
        11.*) # not Express
            case $choice in
                sun4*:*:*:*)    oldarch=sparc_solarisD; arch=solaris11+.sparc ;;
                i86pc:*:*:*)    oldarch=x86_solarisD; arch=solaris11+.x86 ;;
            esac
            ;;
    esac
}

PB_Installplatform_x86_64_linuxArch()
{
	oldarch=x86_64_linuxA; arch=linux.x86-64
        #SY_IsRHEL5TargetedSELinuxInstalled
        #if [ $? -eq 1 ];then
        #	arch=x86_64_linuxB
        #fi
}

PB_Installplatform_x86_linuxArch()
{
	oldarch=x86_linuxB; arch=linux.x86-32
        #SY_IsRHEL5TargetedSELinuxInstalled
        #if [ $? -eq 1 ];then
        #	arch=x86_linuxC
        #fi
}



get_pbul_arch()
{
choice=$1
dfKsearch=""
dfKfreeField=4
dfKstrange="no"
inst_logdir=/var/log
case "$choice" in
	alpha:OSF1:V4*:*)       	arch=unsupported ;;
	alpha:OSF1:V5*:*)       	arch=unsupported ;;
        9000/[78]??:HP-UX:*.11.*:*)	PB_Installplatform_hp11Arch;  inst_logdir=/var/adm; dfKsearch=" free "; dfKfreeField=1; dfKstrange="yes" ;;
        9000/[78]??:HP-UX:*:*)  	arch=unsupported; inst_logdir=/var/adm; dfKsearch=" free "; dfKfreeField=1; dfKstrange="yes" ;;
	ia64:HP-UX:*:*)			PB_Installplatform_ia64hpuxArch;  inst_logdir=/var/adm; dfKsearch=" free "; dfKfreeField=1; dfKstrange="yes" ;;
	ia64:Linux:*:*)                 oldarch=ia64_linuxA; arch=linux.rhel.ia64; inst_logdir=/var/log ;;
	*:IRIX:6*:*)            	arch=unsupported ;;
	*:IRIX64:6*:*)          	arch=unsupported ;;
	*:AIX:*:4)              	arch=unsupported; inst_logdir=/usr/adm; dfKfreeField=3 ;;
	*:AIX:1:5)              	arch=unsupoorted; inst_logdir=/usr/adm; dfKfreeField=3 ;;
	*:AIX:*:[567])              	oldarch=rs6000_aixC; arch=aix52+; inst_logdir=/usr/adm; dfKfreeField=3 ;;
	sun4*:SunOS:5.11:*)      	PB_Installplatform_sol11Arch; inst_logdir=/var/adm ;;
	sun4*:SunOS:5.9:*)      	oldarch=sparc_solarisC; arch=solaris9-10.sparc; inst_logdir=/var/adm ;;
	sun4*:SunOS:5.8:*)      	oldarch=sparc_solarisC; arch=solaris9-10.sparc; inst_logdir=/var/adm ;;
	sun4*:SunOS:5.7:*)      	arch=unsupported; inst_logdir=/var/adm ;;
	sun4*:SunOS:5.6:*)       	arch=unsupported; inst_logdir=/var/adm ;;
	sun4*:SunOS:5.5*:*)       	arch=unsupported; inst_logdir=/var/adm ;;
	sun4*:SunOS:5.4:*)       	arch=unsupported; inst_logdir=/var/adm ;;
	sun4*:SunOS:5.*:*)       	oldarch=sparc_solarisC; arch=solaris9-10.sparc; inst_logdir=/var/adm ;;
	sun4*:SunOS:4*:*)       	arch=unsupported; inst_logdir=/var/adm ;;
	i[34]86:DYNIX/ptx:4*:*) 	arch=unsupported ;;
	i[34]86:SCO_SV:3.2:*)   	arch=unsupported ;;
	i?86:UnixWare:5:7.*)    	arch=unsupported ;;
	*:QNX:*:425)            	arch=unsupported ;;
	s390:Linux:2.6.*)		arch=unsupported; inst_logdir=/var/log ;;
	s390x:Linux:3.*)		oldarch=s390x_linuxB; arch=linux.s390x; inst_logdir=/var/log ;;
	s390x:Linux:2.6.*)		oldarch=s390x_linuxB; arch=linux.s390x; inst_logdir=/var/log ;;
        x86_64:Linux:4.*.*:*)           PB_Installplatform_x86_64_linuxArch; inst_logdir=/var/log ;;
        x86_64:Linux:3.*.*:*)           PB_Installplatform_x86_64_linuxArch; inst_logdir=/var/log ;;
        x86_64:Linux:2.6.*:*)           PB_Installplatform_x86_64_linuxArch; inst_logdir=/var/log ;;
	x86_64:Linux:2.[24].[2-9]*:*)   oldarch=x86_64_linuxA; arch=linux.x86-64; inst_logdir=/var/log ;;
	i686:Linux:2.4.[0-9]-e.*:*)     arch=unsupported ;;
	i686:Linux:2.4.1[0-9]-*.*:*)    arch=unsupported ;;
	i[3456]86:Linux:2.6.*)	        PB_Installplatform_x86_linuxArch; inst_logdir=/var/log ;;
	i[3456]86:Linux:2.[24].[2-9]*:*) oldarch=x86_linuxB; arch=linux.x86-32; inst_logdir=/var/log ;;
	i[3456]86:Linux:2.[24].*:*)     arch=unsupported ;;
	i[3456]86:Linux:2.*.*:*)        oldarch=x86_linuxB; arch=linux.x86-32; inst_logdir=/var/log ;;
	i[3456]86:Linux:2.*:*)          arch=unsupported ;;

	3[34]??:*:4.0:3.0|3[34]??A:*:4.0:3.0|3[34]??,*:*:4.0:3.0|3[34]??/*:*:4.0:3.0|4850:*:4.0:3.0|SKA40:*:4.0:3.0)
	    uname -p 2>/dev/null | ${grep:-grep} 86 >/dev/null
	    if test $? ; then 
	       arch=unsupported
	    else 
	        uname -p 2>/dev/null | ${grep:-grep} entium >/dev/null
		if test $? ; then 
		    arch=unsupported
		fi
	    fi
	    ;;

	3[34]??:*:4.0:*|3[34]??,*:*:4.0:*)
	    uname -p 2>/dev/null | ${grep:-grep} 86 >/dev/null
	    if test $? ; then
	        arch=unsupported
	    fi
	    ;;
	*:UNIX_SV:4.[02]:*)        	arch=unsupported ;;
	i86pc:SunOS:5.11:*)      	PB_Installplatform_sol11Arch; inst_logdir=/var/adm ;;
	i86pc:SunOS:5.7:*)      	arch=unsupported; inst_logdir=/var/adm ;;
	i86pc:SunOS:5.8:*)      	oldarch=x86_solarisB; arch=solaris9-10.x86; inst_logdir=/var/adm ;;
	i86pc:SunOS:5*:*)       	oldarch=x86_solarisB; arch=solaris9-10.x86; inst_logdir=/var/adm ;;
	i*86:FreeBSD:4.0*:*)		arch=unsupported ;;
	Power*Macintosh*:Darwin*:[89].*.*:*) arch=unsupported ;;
	i386*:Darwin*:9.*.*:*|i386*:Darwin*:10.*.*:*)	oldarch=i386_appleA; arch=macosx; inst_logdir=/var/log ;;
	x86_64:Darwin*:1[1-4].*.*:*)	oldarch=i386_appleA; arch=macosx; inst_logdir=/var/log ;;
	ppc64le*:Linux:*)		oldarch=powerpc64le_linuxA; arch=linux.rhel.ppc64le; inst_logdir=/var/log ;;
	ppc64*:Linux:*)			
                val=`getconf LONG_BIT`
                if [ "X$val" = "X32" ] ; then
                        oldarch=powerpc_linuxA; arch=linux.suse.ppc
                else
                        oldarch=powerpc64be_linuxA; arch=linux.rhel.ppc64be
                fi
                inst_logdir=/var/log ;;
	ppc*:Linux:*)			oldarch=powerpc_linuxA; arch=linux.suse.ppc; inst_logdir=/var/log ;;
	*)                      	arch=unsupported ;;
esac

printData "PowerBroker for Unix & Linux Architecture" "$arch"
if [ "X$arch" = "Xunsupported" ];then
    addError 1000
fi


}

get_uname_msrv()
{
    my_HW=`uname -m`
    my_OS=`uname -s`
    my_OSVer=`uname -r`
    my_OSVer2=`uname -v`
    uname_msrv="${my_HW}:${my_OS}:${my_OSVer}:${my_OSVer2}"

}

checkTimeFormat()
{
    resultTimeFormat=""
    if [ "X$console_time" != "X" ] ; then
        resultTimeFormat=`echo "$console_time" | sed 's/2[0-1][0-9][0-9][0-1][0-9][0-3][0-9][0-2][0-9][0-5][0-9][0-5][0-9]//' 2>/dev/null`
        if [ "X$resultTimeFormat" != "X" ] ; then
            echo "${i_am}: invalid argument for option '-t', format UTC: '20130827154130'"
            addError 1080
        fi
    fi

    if [ "X$console_time" != "X" ] ; then
        check_console_time
    else
        my_offset="not checked"
    fi

    if [ ! -z "$mtool_fmt" -o ! -z "$console_time" ]; then
        printData "Check time against console" "$my_offset"
    fi
}

do_version()
{
    cksum ${i_am_from}/${i_am} >/dev/null 2>&1
    if [ $? -eq 0 ] ; then
        sum="cksum = \"`cat ${i_am_from}/${i_am} | cksum 2>/dev/null | awk '{print $1}' 2>/dev/null`\""
    else
        sum=""
    fi
    echo "${i_am}: Ident: \$Revision: 1.1.4.3.2.7 $ \$ ${sum} "
    return 0

}

help()
{
if [ $? -lt 2 ] ; then
        help_stat=1
else
        help_stat=$2
fi
#echo "Usage ${i_am} [-fhv] [-m master] [-m master] [-p prefix] [-s suffix] [-t time]"  1>&2
echo "Usage ${i_am} [-fhv] [-m Policy Server [-m Policy Server ...]] [-t time]"  1>&2
if [ $1 = "short" ] ; then echo " " 1>&2 ;  exit 1 ; fi
echo "    -f : output in 'mtool' format" 1>&2
echo "    -h : print this help message" 1>&2
echo "    -m : PowerBroker for Unix & Linux Policy Server; multiple '-m' args allowed" 1>&2
#echo "    -p : set the pb installation prefix" 1>&2
#echo "    -s : set the pb installation suffix" 1>&2
echo "    -t : pass script console time in unix long time UTC format e.g. 20130903150030" 1>&2
echo "    -v : print ident of installer and exit" 1>&2
echo " " 1>&2
exit $help_stat

}

processArgs()
{
    do_help=no
    help_stat=0
    my_masternames=""
    $getopt fhm:p:s:t:v $* > /dev/null 2>&1
    argsstat=$?
    set -- `$getopt fhm:p:s:t:v $*`
    if [ "$argsstat" = "0" ]; then
        while [ "x$1" != "x--" -a "x$1" != "x" ]; do
            case "$1" in
                -f)    mtool_fmt="yes";;
                -h)    do_help=long;;
                -m)    my_masternames="$my_masternames $2"; shift;;
                -p)    prefix=$2; shift;;
                -s)    suffix=$2; shift;;
                -t)    console_time=$2; shift;;
                -v)    doversion=yes; shift;;
                 *)    if [ "$do_help" = "no" ] ; then
                           do_help=short
                           help_stat=1
                       fi
                       ;;
            esac
            shift
        done
        if [ "X$1" = "X--" ] ; then
            shift
        fi
        if [ "X$*" != "X" ] ; then
            echo " "
            echo "Invalid parameters '$*' were specified on the end of the command"
            echo " "
            help_stat=1
        fi
    else
        do_help=short
        help_stat=1
    fi
    if [ "$do_help" != "no" ] ; then
        help "$do_help" "$help_stat"
    fi
    if [ "X$doversion" = "Xyes" ] ; then
        do_version
        exit 0
    fi

}

checkGetopt()
{
    getopt "x" -x >/dev/null 2>&1
    if [ $? -ne 0 ] ; then
        echo "${i_am}: getopt test returned non-zero result."
        addError 2000
        printMtoolErrors
        exit 1
    else
        getopt=getopt
    fi

}


whoAmI()
{
myfullname=$0
i_am_from=`dirname $myfullname`

case X$i_am_from in
        X/*)
                ;;
        X./*)
                i_am_from="`echo $i_am_from | sed -e 's/^\.\///'`"
                i_am_from="`pwd`/$i_am_from"
                ;;
        X*)
                i_am_from="`pwd`/$i_am_from"
                ;;
esac

i_am="`basename $myfullname`"


}

check_existing_pbul()
{
    pbul_exists="no"
    pbul_roles=""
    pbrun_version=""
    pbexpress_version=""

    if [ -f /usr/sbin/pbmasterd -a -f /etc/pb.conf -a "X$pbul_host_master_port_avail" = "Xin use" ]; then
        pbul_exists="yes"
        pbul_roles="policyserver "
    fi
    if [ -f /usr/sbin/pblogd -a "X$pbul_host_log_port_avail" = "Xin use" ]; then
        pbul_exists="yes"
        pbul_roles="${pbul_roles}logserver "
    fi
    if [ -f /usr/sbin/pblocald -a "X$pbul_host_local_port_avail" = "Xin use" ]; then
        pbul_exists="yes"
        pbul_roles="${pbul_roles}runhost "
    fi
    if [ -f /usr/local/bin/pbrun -o -f /usr/local/bin/pbsh -o -f /usr/local/bin/pbksh ]; then
        pbul_exists="yes"
        pbul_roles="${pbul_roles}submithost"
        if [ -f /usr/local/bin/pbrun ];then
            pbrun_version=`/usr/local/bin/pbrun -v 2>&1`
        fi
    else
       if [ -f /usr/local/bin/pbssh ]; then
            pbul_exists="yes"
            pbul_roles="${pbul_roles}pbx"
            pbexpress_version=`/usr/local/bin/pbssh -v 2>&1`
       fi
    fi

# TBD /usr/sbin/pbguid
# TBD /usr/sbin/pbsguid
# TBD /usr/sbin/pbsyncd

        printData "PowerBroker for Unix & Linux exists" "$pbul_exists"
        if [ "X$pbul_exists" = "Xyes" ]; then
            printData "PowerBroker for Unix & Linux roles" "$pbul_roles"
            if [ "X$pbrun_version" != "X" ];then
                printData "pbrun version" "$pbrun_version"
            else 
                if [ "X$pbexpress_version" != "X" ];then
                    printData "pbssh version" "$pbexpress_version"
                fi
            fi
        fi
}

calculate_installable()
{
    PBULinstallable="yes"
    if [ "X$pbul_exists" = "Xyes" ]; then
        PBULinstallable="installed"
    else
        if [ $name_resolution_errors -eq 1 ]; then
            PBULinstallable="no"
        fi
        #if [ "X$resolv_check" != "Xpassed" ]; then
        #    PBULinstallable="no"
        #fi
#        if [ "X$nsswitch_check" != "Xpassed" ]; then
#            if [ "X$nsswitch_check" != "Xnot applicable" ]; then
#                PBULinstallable="no"
#            fi
#        fi
        if [ "X$NIC_Failures" = "Xyes" ]; then
            PBULinstallable="no"
        fi
        if [ "X$arch" = "Xunsupported" ]; then
            PBULinstallable="no"
        fi
    
        if [ "X$pbul_host_master_port_avail" != "Xavailable" ]; then
            PBULinstallable="no"
        fi
        if [ "X$pbul_host_local_port_avail"  != "Xavailable" ]; then
            PBULinstallable="no"
        fi
        if [ "X$pbul_host_log_port_avail"  != "Xavailable" ]; then
            PBULinstallable="no"
        fi
        if [ "X$pbul_host_guid_port_avail"  != "Xavailable" ]; then
            PBULinstallable="no"
        fi
        if [ "X$pbul_host_sguid_port_avail"  != "Xavailable" ]; then
            PBULinstallable="no"
        fi
        if [ "X$pbul_host_syncd_port_avail"  != "Xavailable" ]; then
            PBULinstallable="no"
        fi

        if [ $hostname_error -eq 1 ];then
            PBULinstallable="no"
        fi
    
        if echo "$my_sdstat" | grep "not running" >/dev/null 2>&1 ; then
            PBULinstallable="no"
        fi

        if [ "X$selinuxtype" = "Xstrict" ];then
            PBULinstallable="no"
            addError 2040 $selinuxtype
        fi
        if [ $diskspace_failed -eq 1 ];then
            PBULinstallable="no"
        fi
    fi

    if [ "X$PBULinstallable" = "Xno" ]; then
        addError 3040
    fi

    printData "PowerBroker for Unix & Linux Installable" "$PBULinstallable"
}

check_partition_diskspace()
{

    bt_normalizeDfAwkProg='BEGIN { old_dollar1="" } NF == 1 { old_dollar1=$1; next } old_dollar1 != "" { print old_dollar1, $0; next } { print $0 } '

    if [ "X$dfKstrange" = "Xyes" ] ; then
        freespace=`df -k $1 2>/dev/null | $awk "${bt_normalizeDfAwkProg}" 2>/dev/null | grep "$dfKsearch" | $awk '{print $'$dfKfreeField'}' 2>/dev/null`
    else 
        freespace=`df -k $1 2>/dev/null | $awk "${bt_normalizeDfAwkProg}" 2>/dev/null | grep -v Mounted | $awk '{print $'$dfKfreeField'}' 2>/dev/null`
    fi

    if [ -z "$freespace" ];then
            printData "Disk space for" "$1 check failed"
            addError 2060 $1
            diskspace_failed=1
    else
        if [ $freespace -lt $2 ];then
            printData "Disk space for" "$1:$freespace insufficient"
            addError 2050 $1 "$freespace"
            diskspace_failed=1
        else
            if [ $freespace -lt $3 ];then
                printData "Disk space for" "$1:$freespace below recommended $3 KB"
            else
                printData "Disk space for" "$1:$freespace OK"
            fi
        fi
    fi
}

check_disk_space()
{
    if [ "X$arch" != "Xunknown" ]; then
        check_partition_diskspace /usr/sbin 50000 50000
        check_partition_diskspace /usr/local/bin 50000 50000
        check_partition_diskspace $inst_logdir 50000 1000000
    fi
}

#
# main()
#
LANG=C
LC_ALL=C
LANGUAGE=C; LC_MONETARY=C ; LC_NUMERIC=C 
LC_MESSAGES=C ; LC_COLLATE=C ;  LC_CTYPE=C ; LC_TIME=C

exit_status_installable=0

whoAmI

checkGetopt

processArgs $*
if [ "X$mtool_fmt" = "Xyes" ] ; then
    errorFile="${i_am_from}/errorlist"
    warningFile="${i_am_from}/warninglist"

    /bin/rm -f $errorFile
    /bin/rm -f $warningFile
fi

checkTimeFormat

get_uname_msrv
get_pbul_arch $uname_msrv


set_OSVer

# fix this LB
#    PATH=$PATH:/sbin

set_OSVars

set_variables

hostname_error=0
get_hostname

check_selinux_mode

validate_etchosts
    
validate_resolv

name_resolution_errors=0
validate_nameresol "$my_hostname"
validate_nsswitch # moved, needs ipaddresses

if [ "X$my_masternames" != "X" ] ; then
    for mastername in $my_masternames ; do
        validate_nameresol "$mastername"
    done
fi
print_validate_nameresol


check_NICs

get_defgateway

get_domainname

    # phase 2

check_superdaemon

check_local_pbul_ports_avail

    #check_local_pbul_ports_blocked

check_existing_pbul

diskspace_failed=0
check_disk_space

printMtoolErrors
printMtoolWarnings

calculate_installable

exit ${exit_status_installable}
