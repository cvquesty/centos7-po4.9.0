#!/bin/sh
#
# Copyright 2015 BeyondTrust Software
#
# pbsnapshot.sh
#
# Collect PBUL and OS configuration for support evaluation.
#
PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
export PATH

abort () { echo >&2 "$*"; exit 1; }

# stop if not running as root
[ 0 -eq `PATH=/usr/xpg4/bin:$PATH id -u` ] || abort must run as root

nodename=`uname -n | cut -f1 -d.`
datetime=`date +%y%m%d%H%M%S`

base=pbsnapshot
name=`basename $0 .sh`
: ${name:=$base}
tmpbase="/tmp/.${name}.$$"

# determine prefix and suffix from script name
# (bourne does not make this easy)
echo "${name:-$base}" | sed -e "s/$base/ /g" >$tmpbase
[ -s "$tmpbase" ] && read prefix suffix junk <$tmpbase
unlink $tmpbase

fevlogs=${tmpbase}.eventlogs
fiologs=${tmpbase}.iologs

# funtion to output usage and terminate
usage () {
cat - >&2 <<_HELP_

usage: $name [-h] [-p pfx] [-s sfx] [-n|-y [-e path]... [-i path]...]]

   h   show help
   p   specify PBUL prefix
   s   specify PBUL suffix
   n   do not collect privileged data
   y   collect privileged data       (policies, events and iologs)
   e   include specified eventlog(s) (requires -y)
   i   include specified iolog(s)    (requires -y)

_HELP_
}

#
# process command line arguments
#
while getopts 'hynp:s:e:i:' opt
do
	case "$opt" in
	y) priv=true  ;; # collect privileged data
	n) priv=false ;; # do not collect privileged data

	p) [ "X$OPTARG" != "X" ] && prefix="$OPTARG" ;; # prefix
	s) [ "X$OPTARG" != "X" ] && suffix="$OPTARG" ;; # suffix

	# build eventlog list
	e)	if [ -n "$OPTARG" ]
		then for evlog in $OPTARG
			do [ -s $evlog ] && echo $evlog
			done >>$fevlogs
		fi ;;

	# build iolog list
	i)	if [ -n "$OPTARG" ]
		then for iolog in $OPTARG
			do [ -s $iolog ] && echo $iolog
			done >>$fiologs
		fi ;;

	h) usage; exit 0 ;;
	*) usage; exit 1 ;;
	esac
done

# variables to reference prefixed settings
pb_settings=/etc/${prefix}pb.settings${suffix}
pb_cfg=/etc/${prefix}pb.cfg${suffix}

# stop if pb.settings is missing
[ -s "$pb_settings" ] || abort $pb_settings is missing or empty

# go to a convenient temp directory
cd /tmp || cd /var/tmp || abort no temp space available

# create and enter snapshot folder
tmpdir="${name}.${nodename}.${datetime}.$$"
[ -d "$tmpdir" ] || mkdir -p "$tmpdir"
cd "$tmpdir" || abort could not access $tmpdir

# 1-MB for tail -c
c=1048576

# redirect shell activity to a log file
# fd 3 and 4 are dups of 1 and 2 for prompts and messages
# fd 9 is useful for trashing unwanted output
exec 3>&1 4>&2 >${name}.log 2>&1 9>/dev/null
set -x

# create variables to reference prefixed binaries
while read list
do	for binary in $list
	do eval pb${binary}=${prefix}pb${binary}${suffix}
	done
done <<_LIST_
bench call check dbutil hostid key ksh license
locald log logd masterd ping print register
replay report run sh ssh sum syncd version
_LIST_

#
# functions
#

# output boolean setting with pbcall
get_yesno_setting () {
	$pbcall -getyesnosetting "$@"
}

# output string setting with pbcall
get_string_setting () {
	$pbcall -getstringsetting "$@"
}

# output list setting with pbcall,
# converting all comas to spaces
get_list_setting () {
	$pbcall -getlistsetting "$@" | tr -s ',' ' '
}

# command wrapper
# generate comments to log file via stderr
# send notification to terminal via dup fd
# run the command line
# return the result (ok or error)
do_cmd () {
	[ $# -gt 0 ] || return 1
	printf >&2 '###\n### %s \n###\n' "$*"
	printf >&3 '%s... ' "$*"
	"$@" <&9
	rc=$?
	[ $rc -eq 0 ] && echo >&3 ok. || echo >&3 error.
	return $rc
}

#
# if input is a terminal...
#
if [ -t 0 ]
then
	#
	# unless -y or -n command line options were used,
	# then ask for permission to collect privileged data
	#
	if [ "X$priv" = "X" ]
	then
		printf >&3 '\n\nCollect privileged information? (yes or no) '
		read answer junk
		case "$answer" in
		[Yy]|[Yy][Ee][Ss]) priv=true ;;
		*) priv=false ;;
		esac
	fi

	#
	# if permission is affirmative...
	#
	if ${priv:-false}
	then
		#
		# ask for eventlogs if not already provided on command line
		#
		if [ ! -s $fevlogs ]
		then
			printf >&3 '\n\nEnter full paths to relevant eventlogs and press enter when done:\n> '
			while read list
			do	[ "X$list" = "X" ] && break
				for evlog in $list
				do	if [ -s $evlog ]
					then echo $evlog
					else echo >&4 "$evlog: empty or missing"
					fi
				done
				printf >&4 '> '
			done >>$fevlogs
		fi

		#
		# ask for iologs if not already provided on command line
		#
		if [ ! -s $fiologs ]
		then
			printf >&3 '\n\nEnter full paths to relevant iologs and press enter when done:\n> '
			while read list
			do	[ "X$list" = "X" ] && break
				for iolog in $list
				do	if [ -s $iolog ]
					then echo $iolog
					else echo >&4 "$iolog: empty or missing"
					fi
				done
				printf >&4 '> '
			done >>$fiologs
		fi
	fi
fi


############################################################
#
# get started
#

# record current date and time
date >date

# determine operating platform
# write uname output to file, then "read" from it into variables
# (uname|read will not work since pipelines are often invoked as subshells)
uname -snrm >uname
[ -s uname ] && read system nodename release machine junk <uname

# source pb.cfg if available
[ -s "$pb_cfg" ] && . "$pb_cfg"

# assign default values in case pb.cfg is lacking
: ${inst_userdir:=/usr/local/bin}
: ${inst_admindir:=/usr/sbin}
: ${inst_daemondir:=/usr/sbin}

# copy pb.settings and pb.cfg to the working directory
for f in $pb_settings $pb_cfg
do [ -s "$f" ] && do_cmd cp "$f" .
done

# prepend paths to pbul binaries to PATH
PATH="${inst_userdir}:${inst_admindir}:${inst_daemondir}:${PATH}"
export PATH

############################################################
#
# PBUL
#

# all binary versions
do_cmd $pbversion >versions.out

# PB host identifier
do_cmd $pbhostid >pbhostid.out

# run pbbench diagnostics utility
do_cmd $pbbench -V >pbbench.out

# licensing report
do_cmd $pblicense -l >pblicense.out

# general connection checks
if type $pbrun
then
	for mode in '' '--di'
	do do_cmd $pbrun -d connect $mode -np id
	done
fi </dev/null >pbrun-connect.out

# v7 connection checks
if type $pbping
then
	do_cmd $pbbench -m -l
	for h in localhost $nodename
	do	do_cmd $pbping -h $h
	done
fi </dev/null >pbping.out

# collect non-empty pbul logfiles
for s in pbrunlog kshlog shlog pbsshlog pbmasterdlog pblogdlog pblocaldlog
do
	l=`get_string_setting $s`
	[ "X$l" = "X" ] && [ -s "$l" ] || continue
	do_cmd tail -${c}c $l >`basename $l`
done

# policy syntax check
do_cmd $pbcheck -t >pbcheck.out

############################################################
#
# the privileged operations
#

# if permission is affirmative...
if ${priv:-false}
then
	# create collection folders
	mkdir policy events iologs

	# starting with the primary policy file...
	policydir=`get_string_setting policydir`
	get_string_setting policyfile > .includes
	# recursively collect included policy files
	# use pbprint in case policies are encrypted
	while [ -s .includes ]
	do	while read policy junk
		do	case "$policy" in
			../*) policy= ;; # no dots please
			./*)  policy= ;; # no dots please
			/*)   ;;         # good, full path to policy
			'')   ;;         # empty line
			*)    policy=$policydir/$policy ;; # relative path
			esac
			# do not try to process a missing or empty policy
			[ -s $policy ] || continue
			# do not reprocess policies (avoids infinite loops)
			output=policy/$policy
			[ -s $output ] && continue
			# reproduce policy tree structure
			outdir=`dirname $output`
			[ -d $outdir ] || mkdir -p $outdir
			# pretty print the policy
			do_cmd $pbprint -f $policy >$output
			# discover its included policies,
			# strip quotes and semi-colons
			awk '/^include /{print $2}' $output | tr -d "'"'";'
		done <.includes >.includes.next
		mv .includes.next .includes
	done
	unlink .includes

	# ensure the default eventlog will be processed
	get_string_setting eventlog >>$fevlogs

	# dump recent events from specified eventlog files
	while read evlog junk
	do	# skip missing or empty eventlog
		[ -s "$evlog" ] || continue
		# avoid redundant dumps
		eoutf=events/$evlog
		[ -s $eoutf ] && continue
		# reproduce log tree structure
		eoutd=`dirname $eoutf`
		[ -d $eoutd ] || mkdir -p $eoutd
		# extract the last 1MB of the eventlog
		do_cmd $pblog -d -l -f $evlog | tail -${c}c >$eoutf
	done <$fevlogs
	unlink $fevlogs

	# extract event header and stdio of specified iolog(s)
	while read iolog junk
	do	# skip missing or empty iolog
		[ -s $iolog ] || continue
		# avoid redundant dumps
		ioutf=iologs/$iolog
		[ -s ${ioutf}.Ioe ] && continue
		# reproduce iolog tree structure
		ioutd=`dirname $ioutf`
		[ -d $ioutd ] || mkdir -p $ioutd
		# dump event header
		do_cmd $pbreplay -av $iolog >${ioutf}.av
		# extract readable stdio
		do_cmd $pbreplay -ax -Ioe $iolog >${ioutf}.Ioe
		# create v7 "indexable" output
		do_cmd $pbreplay -O $iolog >${ioutf}.O
	done <$fiologs
	unlink $fiologs

fi # pbul priv

############################################################
#
# Operating System
#
case "$system" in
Linux)
	type sestatus && do_cmd sestatus -vb
	type lsb_release && do_cmd lsb_release -a
	do_cmd cat /etc/*-release
	do_cmd lsmod >lsmod
	do_cmd dmesg >dmesg
	;;

SunOS)
	do_cmd isalist >isalist
	do_cmd prtconf -v >prtconf-v
	do_cmd sysdef >sysdev
	do_cmd modinfo >modinfo
	do_cmd dmesg >dmesg
	;;

AIX)
	do_cmd oslevel >oslevel
	do_cmd lsconf >lsconf
	do_cmd errpt >errpt
	;;

HP-UX)
	do_cmd model >model
	do_cmd kctune -g >kctune-g
	do_cmd machinfo -v >machinfo-v
	do_cmd lsdev >lsdev
	do_cmd dmesg >dmesg
	;;

Darwin)
	do_cmd sw_vers >sw_vers
	do_cmd dmesg >dmesg
	;;

esac

############################################################
#
# Networking
#

do_cmd hostname >hostname
do_cmd domainname >domainname

# network interfaces
case "$system" in
Linux)
	if type ip
	then
		do_cmd ip link >ip.link
		do_cmd ip addr >ip.addr
		do_cmd ip -f inet  route >ip.route.4
		do_cmd ip -f inet6 route >ip.route.6
	else
		do_cmd ifconfig -a >ifconfig-a
		do_cmd netstat -rn4 >netstat-rn4
		do_cmd netstat -rn6 >netstat-rn6
	fi
	;;

SunOS)
	ifconfig -a plumb
	do_cmd ifconfig -a >ifconfig-a
	do_cmd netstat -rn >netstat-rn
	;;

HP-UX)
	do_cmd lanscan -v >lanscan-v
	for lan in `lanscan -i`
	do do_cmd ifconfig $lan >ifconfig.$lan
	done
	do_cmd netstat -rn >netstat-rn
	;;

*)
	do_cmd ifconfig -a >ifconfig-a
	do_cmd netstat -rn >netstat-rn
	;;
esac >networking

for f in hosts resolv.conf nsswitch.conf
do [ -s "/etc/$f" ] && do_cmd cp "/etc/$f" .
done

# how does pbul resolve my nodename?
do_cmd $pbcall -ipaddress $nodename >ipaddress
[ -s ipaddress ] && read ipaddress junk <ipaddress

# host does the system resolve my nodename and IP
for key in $nodename $ipaddress
do	for cmd in host nslookup
	do	do_cmd $cmd $key && break
	done
done >resolver

# dump firewall rules
case "$system" in
Linux)
	for cmd in iptables ip6tables
	do do_cmd $cmd -nL >$cmd
	done
	;;
esac

# list open tcp ports
case "$system" in
Linux)
	if ! do_cmd lsof -nPi tcp >lsof-nPi
	then do_cmd netstat -an >netstat-an
	fi
	;;

*)	do_cmd netstat -an >netstat-an ;;
esac


############################################################
#
# Storage
#
# (detect EMC, HDS, or other enterprise storage arrays?)
#
case "$system" in
Linux)
	do_cmd df -k >df
	do_cmd mount >mount
	[ -s /etc/fstab ] && do_cmd cp /etc/fstab .
	do_cmd fdisk -l >fdisk-l
	do_cmd vgdisplay >vgdisplay
	do_cmd lvdisplay >lvdisplay
	do_cmd pvdisplay >pvdisplay
	;;

HP-UX)
	do_cmd bdf -k >bdf
	do_cmd mount >mount
	[ -s /etc/fstab ] && do_cmd cp /etc/fstab .
	do_cmd vgdisplay -v >vgdisplay
	for vg in /dev/*/group
	do	vg=`dirname $vg`
		do_cmd lvdisplay `find $vg -type b`
	done >lvdisplay
	# pvdisplay?
	;;

SunOS )
	do_cmd df -k >df
	do_cmd mount >mount
	[ -s /etc/vfstab ] && do_cmd cp /etc/vfstab .
	for d in /dev/dsk/c*t*d*s2
	do	do_cmd prtvtoc $d
	done >prtvtoc
	# LVM?
	;;

*)
	do_cmd df -k >df
	do_cmd mount >mount
	[ -s /etc/fstab ] && do_cmd cp /etc/fstab .
	;;

esac >storage

############################################################
#
# Memory
#

############################################################
#
# Processes
#

do_cmd w >w
do_cmd ps -ef >ps-ef

# top? sar? others?

############################################################
#
# Services or Subsystems
#
do_cmd grep "^${prefix}pb.*d${suffix}" /etc/services >services

if [ -s /etc/inetd.conf ]
then do_cmd grep "^${prefix}pb.*d${suffix}" /etc/inetd.conf >inetd.conf
fi

if [ -d /etc/xinetd.d ]
then do_cmd cat /etc/xinetd.d/${prefix}pb*d${suffix} >xinetd.conf
fi

case "$system" in
Linux)
	if type systemctl
	then do_cmd systemctl list-units >systemctl-list-units
	elif type chkconfig
	then do_cmd chkconfig --list >chkconfig--list
	fi
	;;

SunOS)
	do_cmd svcs -a >svcs-a
	do_cmd svccfg list >svccfg-list
	;;

AIX)
	do_cmd lssrc -a >lssrc-a
	;;

Darwin)
	do_cmd launchctl list >launchctl_list
	;;
esac

############################################################
#
# Installed Software Packages
#
case "$system" in
SunOS) do_cmd pkginfo -ix ;;
HP-UX) do_cmd swlist -R ;;
AIX) do_cmd lslpp -L all ;;
Linux)
	# try rpm (rhel,suse)
	# then dpkg (debian,ubuntu)
	for cmd in 'rpm -qa' 'dpkg-query -l'
	do do_cmd $cmd && break
	done
	;;
esac >packages

# close log file and restore sdtio before archiving
set +x
exec >&3 2>&4 3>&- 4>&-

############################################################
#
# wrap it all up
#
cd ..
tarfile=`pwd`/`basename $tmpdir .$$`.tar
tar cf $tarfile $tmpdir >&9 2>&9 || abort tar failed
[ -s $tarfile ] || abort $tarfile is empty or missing

# we have a tar; now remove the folder
rm -rf "$tmpdir" >&9 2>&9

# zip it up with something handy
for z in bzip2/bz2 gzip/gz zip/zip compress/Z
do	zipper=`dirname $z` x=`basename $z`
	type $zipper || continue
	$zipper $tarfile
	# if zipper worked, clean up and break out
	[ -s $tarfile.$x ] && rm -f $tarfile && break
done >&9 2>&9

[ -s "$tarfile.$x" ] && tarfile="$tarfile.$x"
# if zippers failed, then we still have a tarball

# disclaimer
cat - <<-_CAT_

The archive is ready here:
$tarfile

*************************************************************
*  CAUTION: Sensitive information may have been collected.  *
*    Please review the archive carefully before sending.    *
*************************************************************

_CAT_

exit 0
